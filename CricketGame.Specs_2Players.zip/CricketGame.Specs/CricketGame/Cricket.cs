﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CricketGame
{
    public class Cricket
    {
        public int PlayerScore { get; set; }

       // public string GameResult { get; set; }
        public bool PlayerStatus { get; set; }

        public string GameResult(int player1Score, int player2Score)
        {
            if (player1Score > player2Score)
                return "Player1 is winner";
            else if (player1Score < player2Score)
                return "Player2 is winner";
            else
                return "Tie";
        }
        public void Score(int runs)
        {
            if (runs < 0)
                PlayerScore = PlayerScore;

            if (runs > 6 || runs == 0)
                PlayerScore += 0;

            else
                PlayerScore += runs;

        }
    }
}
