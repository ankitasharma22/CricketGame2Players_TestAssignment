﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CricketGame;

namespace CricketGame.Test
{
    [TestClass]
    public class CricketGameTests
    {
        [TestMethod]
        public void Player1Score_NewGame_ShouldbeZero()
        {
            var game1 = new Cricket();
            Assert.IsTrue(game1.PlayerScore == 0);
        }

        [TestMethod]
        public void Score_ValidRuns_ShouldUpdatePlayer1Score()
        {
            var game1 = new Cricket();
            game1.Score(3);
            Assert.IsTrue(game1.PlayerScore == 3);
        }

        [TestMethod]
        public void Score_InValidRuns_ShouldUpdatePlayer1Score()
        {
            var game1 = new Cricket();
            game1.Score(7);
            Assert.IsTrue(game1.PlayerScore == 0);
        }

        [TestMethod]
        public void Score_Negative_ShouldUpdatePlayer1Score()
        {
            var game1 = new Cricket();
            game1.Score(-1);
            Assert.IsTrue(game1.PlayerScore == game1.PlayerScore);
        }


        [TestMethod]
        public void Player2Score_NewGame_ShouldbeZero()
        {
            var game2 = new Cricket();
            Assert.IsTrue(game2.PlayerScore == 0);
        }

        [TestMethod]
        public void Score_ValidRuns_ShouldUpdatePlayer2Score()
        {
            var game2 = new Cricket();
            game2.Score(3);
            Assert.IsTrue(game2.PlayerScore == 3);
        }

        [TestMethod]
        public void Score_InValidRuns_ShouldUpdatePlayer2Score()
        {
            var game2 = new Cricket();
            game2.Score(7);
            Assert.IsTrue(game2.PlayerScore == 0);
        }

        [TestMethod]
        public void Score_Negative_ShouldUpdatePlayer2Score()
        {
            var game2 = new Cricket();
            game2.Score(-1);
            Assert.IsTrue(game2.PlayerScore == game2.PlayerScore);
        }
        [TestMethod]
        public void Score_Comparison_OfTwoPlayers_Tie()
        {
            var game1 = new Cricket();
            var game2 = new Cricket();
            game1.Score(2);
            game1.Score(-1);

            game2.Score(2);
            game2.Score(-1);
            string result = game1.GameResult(game1.PlayerScore, game2.PlayerScore);

            Assert.IsTrue(result == "Tie");
        }

        [TestMethod]
        public void Score_Comparison_OfTwoPlayers_WinnerPlayer1()
        {
            var game1 = new Cricket();
            var game2 = new Cricket();
            game1.Score(2);
            game1.Score(-1);

            game2.Score(-1);
            string result = game1.GameResult(game1.PlayerScore, game2.PlayerScore);

            Assert.IsTrue(result == "Player1 is winner");
        }

        [TestMethod]
        public void Score_Comparison_OfTwoPlayers_WinnerPlayer2()
        {
            var game1 = new Cricket();
            var game2 = new Cricket();
            game1.Score(2);
            game1.Score(-1);

            game2.Score(6);
            game2.Score(-1);
            string result = game1.GameResult(game1.PlayerScore, game2.PlayerScore);

            Assert.IsTrue(result == "Player2 is winner");
        }
    }
}
