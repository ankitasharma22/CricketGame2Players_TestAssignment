﻿using FluentAssertions;
using System;
using TechTalk.SpecFlow;

namespace CricketGame.Specs
{
    [Binding]
    public class PlayerScoreSteps
    {
        private Cricket _game1;
        private Cricket _game2;

        [When(@"Player1 has started a game of cricket")]
        [Given(@"Player1 has started a game of cricket")]
        public void WhenPlayer1HasStartedAGameOfCricket()
        {
            // ScenarioContext.Current.Pending();
            _game1 = new Cricket();
        }

        [When(@"Player2 has started a game of cricket")]
        [Given(@"Player2 has started a game of cricket")]
        public void WhenPlayer2HasStartedAGameOfCricket()
        {
            // ScenarioContext.Current.Pending();
            _game2 = new Cricket();
        }

        [Then(@"the player1 score should be (.*)")]
        public void ThenThePlayer1ScoreShouldBe(int score)
        {
            //  ScenarioContext.Current.Pending();
            _game1.PlayerScore.Should().Be(score);
        }

        [Then(@"the player2 score should be (.*)")]
        public void ThenThePlayer2ScoreShouldBe(int score)
        {
            //  ScenarioContext.Current.Pending();
            _game2.PlayerScore.Should().Be(score);
        }

        [Given(@"Player1 has scored (.*) runs")]
      //  [Given(@"Player1 has got out")]
        [When(@"Player1 scores (.*) runs")]
        public void WhenThePlayer1Score4Runs(int score)
        {
            //  ScenarioContext.Current.Pending();
            _game1.Score(score);
            if (score == -1)
                _game1.PlayerStatus = false;
        }

        [Given(@"Player2 has scored (.*) runs")]
        [When(@"Player2 scores (.*) runs")]
    //    [Given(@"Player2 has got out")]
        public void WhenThePlayer2Score4Runs(int score)
        {
            //  ScenarioContext.Current.Pending();
            _game2.Score(score);
            if (score == -1)
                _game2.PlayerStatus = false;
        }

        [Then(@"the player1 score should increase by (.*)")]
        public void ThenThePlayer1ScoreShouldIncreaseBy(int runs)
        {
            _game1.PlayerScore.Should().Be(runs);
        }

        [Then(@"the player2 score should increase by (.*)")]
        public void ThenThePlayer2ScoreShouldIncreaseBy(int runs)
        {
            _game2.PlayerScore.Should().Be(runs);
        }


        [Then(@"the player1 score should not change")]
        public void ThenThePlayer1ScoreShouldRemainSame()
        {
            _game1.PlayerScore.Should().Be(_game1.PlayerScore);
        }

        [Then(@"the player2 score should not change")]
        public void ThenThePlayer2ScoreShouldRemainSame()
        {
            _game2.PlayerScore.Should().Be(_game2.PlayerScore);
        }


        
        [Then(@"the players score should be compared")]
        public void ThenThePlayersScoreShouldBeCompared()
        {
          
        }
    }
}
